import { PREDATOR_LEVEL_THRESHOLD } from "./Parameters";
import { BRAIN_STATE_LOOKING_FOR_FOOD, BRAIN_STATE_LOOKING_FOR_MATE, BRAIN_STATE_LOOKING_FOR_PREY, BRAIN_STATE_PURSUING_FOOD, BRAIN_STATE_PURSUING_MATE, BRAIN_STATE_PURSUING_PREY } from "./Brain";
import { NULL_INDEX, ONE, PI2, PI_OVER_180, ZERO } from "./MathConstants";
import { OLD_AGE_DURATION, SWIMBOT_DOT_RENDER_RADIUS, SWIMBOT_LEVEL_OF_DETAIL_DOT, SWIMBOT_LEVEL_OF_DETAIL_HIGH, SWIMBOT_LEVEL_OF_DETAIL_LOW, YOUNG_AGE_DURATION } from "./Parameters";
import { GENITAL_INDEX, MOUTH_INDEX, NULL_PART, ROOT_PART, STARVING, SWIMBOT_GENITAL_LENGTH, SWIMBOT_MIN_MOUTH_LENGTH, SWIMBOT_MIN_MOUTH_WIDTH, SWIMBOT_MOUTH_WIDTH } from "./SwimbotTypes";
import { Color, assert } from "./Utility";
import { Vector2D } from "./Vector2D";

// predator beaks: red, with light teeth
const PREDATOR_MOUTH_COLOR = "rgb( 190, 38, 30 )";
const PREDATOR_TEETH_COLOR = "rgba( 255, 244, 228, 0.95 )";

export function SwimbotRenderer()
{

var    flopperX = 0;
var    flopperY = 0;
var    flopperXV = 0;
var    flopperYV = 0;

    //---------------------------------
    //  colors
    //---------------------------------
    const COLOR_WHITENESS   = 0.4; // 0.0 = normal-saturated color; 0.5 = white-washed; 1.0 = pure white
    const DEAD_COLOR_RED    = 0.2;
    const DEAD_COLOR_GREEN  = 0.25;
    const DEAD_COLOR_BLUE   = 0.3;
    const ROLLOVER_COLOR    = "rgba( 180, 190, 200, 0.7 )";
    const SELECT_COLOR      = "rgba( 255, 255, 255, 0.8 )";
    const OUTLINE_COLOR     = "rgba( 0, 0, 0, 0.4 )";

    //---------------------------------
    //  spline
    //---------------------------------
    const DEFAULT_SPLINE_FACTOR = 0.4;

    //---------------------------------
    //  egg size
    //---------------------------------
    const EGG_SIZE = 5.0;


	//--------------------------------
	// variables
	//--------------------------------
	let _colorUtility       = new Color();
	let _phenotype          = null; // set by render()
	let _growthScale        = ZERO;
	let _focusDirection     = new Vector2D();
	let _brain              = null; // set by render()
	let _age                = 1000;
	let _energy             = ZERO;
	let _splineFactor       = ZERO;
	let _renderingGenitalsAndMouths = false;
	let _swimbot            = null;



	//----------------------------------------------------
	// get part parent position
	//----------------------------------------------------
	this.getPartParentPosition = function(p)
	{
		if ( _phenotype.parts[p].parent == NULL_PART )
		{
			return _phenotype.parts[0].position;
		}

		return _phenotype.parts[ _phenotype.parts[p].parent ].position;
	}


	//-------------------------------------------
	// set rendering goals
	//-------------------------------------------
	this.setRenderingGoals = function( r )
	{
	    _renderingGenitalsAndMouths = r;
    }


	//-----------------------
	// render
	//-----------------------
	this.render = function
	(
	    phenotype,
	    brain,
	    age,
	    energy,
	    growthScale,
	    focusDirection,
	    levelOfDetail,
	    swimbot
	)

	{

    	_phenotype      = phenotype;
    	_brain          = brain;
    	_age            = age;
    	_energy         = energy;
    	_growthScale    = growthScale;
    	_focusDirection = focusDirection;
    	_swimbot        = swimbot;


		if ( levelOfDetail == SWIMBOT_LEVEL_OF_DETAIL_DOT )
		{

		    let p = 1;

            _colorUtility = this.calculatePartColor(p);

            let red   = Math.floor( _colorUtility.red   * 255 );
            let green = Math.floor( _colorUtility.green * 255 );
            let blue  = Math.floor( _colorUtility.blue  * 255 );

			canvas.fillStyle = "rgb( " + red + ", " + green + ", " + blue + " )";

			let center = _phenotype.parts[ ROOT_PART ].position;
			canvas.beginPath();
			canvas.arc( center.x, center.y, SWIMBOT_DOT_RENDER_RADIUS, 0, PI2, false );
			canvas.fill();


        }
		else if ( levelOfDetail == SWIMBOT_LEVEL_OF_DETAIL_LOW )
		{
			for (let p=1; p<_phenotype.numParts; p++)
			{
				let parentPosition = this.getPartParentPosition(p);

				_colorUtility = this.calculatePartColor(p);
                let red   = Math.floor( _colorUtility.red   * 255 );
                let green = Math.floor( _colorUtility.green * 255 );
                let blue  = Math.floor( _colorUtility.blue  * 255 );

				canvas.strokeStyle = "rgb( " + red + ", " + green + ", " + blue + " )";
				canvas.lineWidth = _phenotype.parts[p].width * 2.0;

				canvas.beginPath();
				canvas.moveTo( parentPosition.x, parentPosition.y );
				canvas.lineTo( _phenotype.parts[p].position.x, _phenotype.parts[p].position.y );
				canvas.closePath();
				canvas.stroke();
			}
		}
		else if ( levelOfDetail == SWIMBOT_LEVEL_OF_DETAIL_HIGH )
		{
			for (let p=1; p<_phenotype.numParts; p++)
			{
				if ( _phenotype.parts[p].length > ZERO )
				{
                    //--------------------------------------------
                    // render the part
                    //--------------------------------------------

                    _splineFactor = DEFAULT_SPLINE_FACTOR;

                    if ( _phenotype.parts[p].splined )
                    {
                        this.renderPartSplined(p);
                    }
                    else
                    {
                        this.renderPartNormal(p);
                    }



                    //--------------------------------------------
                    //--------------------------------------------
                    // if p is mouth part, render mouth!
                    //--------------------------------------------
                    if ( p === 1 )
                    {
                        if ( _renderingGenitalsAndMouths )
                        {
                            if (
                                ( _brain.getState() == BRAIN_STATE_LOOKING_FOR_FOOD	)
                                ||  ( _brain.getState() == BRAIN_STATE_PURSUING_FOOD )
                                ||  ( _brain.getState() == BRAIN_STATE_LOOKING_FOR_PREY )
                                ||  ( _brain.getState() == BRAIN_STATE_PURSUING_PREY )
                            )
                            {
                                this.renderMouth();
                            }

                        }
                    }
				}
			}
		}

        if ( _renderingGenitalsAndMouths )
		{
            //--------------------------------------------
            // render genital!
            //--------------------------------------------
            if (( _brain.getState() == BRAIN_STATE_LOOKING_FOR_MATE	)
            ||  ( _brain.getState() == BRAIN_STATE_PURSUING_MATE ))
            {
                this.renderGenital();
            }
        }

	}// render funtion




	//-------------------------------------------------------------------
	// only the mouth and the genital (the body itself is on the graphics
	// card): the same rules as at the end of render()
	//-------------------------------------------------------------------
	this.renderDetails = function( phenotype, brain, growthScale, focusDirection, swimbot )
	{
	    if ( !_renderingGenitalsAndMouths ) return;
	    _phenotype      = phenotype;
	    _brain          = brain;
	    _growthScale    = growthScale;
	    _focusDirection = focusDirection;
	    _swimbot        = swimbot;
	    const state = _brain.getState();
	    if (( state == BRAIN_STATE_LOOKING_FOR_FOOD ) || ( state == BRAIN_STATE_PURSUING_FOOD )
	    ||  ( state == BRAIN_STATE_LOOKING_FOR_PREY ) || ( state == BRAIN_STATE_PURSUING_PREY ))
	    {
	        this.renderMouth();
	    }
	    if (( state == BRAIN_STATE_LOOKING_FOR_MATE ) || ( state == BRAIN_STATE_PURSUING_MATE ))
	    {
	        this.renderGenital();
	    }
	}

	//-----------------------------------
	// render part normal (not splined)
	//-----------------------------------
	this.renderPartNormal = function(p)
	{
        let width           = _phenotype.parts[p].width;
        let position 		= _phenotype.parts[p].position;
        let parentPosition  = this.getPartParentPosition(p);

        //---------------------------
        // baby growing...
        //---------------------------
        if ( _growthScale < ONE )
        {
            width = width * _growthScale + EGG_SIZE * ( ONE - _growthScale );
        }

        let pp0x = _phenotype.parts[p].perpendicular.x * width;
        let pp0y = _phenotype.parts[p].perpendicular.y * width;

        let pp1x = _phenotype.parts[p].perpendicular.x * width;
        let pp1y = _phenotype.parts[p].perpendicular.y * width;

        let x0 = parentPosition.x - pp1x;
        let y0 = parentPosition.y - pp1y;

        let x1 = parentPosition.x + pp1x;
        let y1 = parentPosition.y + pp1y;

        let x2 = position.x + pp0x;
        let y2 = position.y + pp0y;

        let x3 = position.x - pp0x;
        let y3 = position.y - pp0y;

        _colorUtility = this.calculatePartColor(p);
        let red   = Math.floor( _colorUtility.red   * 255 );
        let green = Math.floor( _colorUtility.green * 255 );
        let blue  = Math.floor( _colorUtility.blue  * 255 );

        canvas.fillStyle = "rgb( " + red + ", " + green + ", " + blue + " )";

        canvas.beginPath();
        canvas.moveTo( x0, y0 );
        canvas.lineTo( x1, y1 );
        canvas.lineTo( x2, y2 );
        canvas.lineTo( x3, y3 );
        canvas.closePath();
        canvas.fill();

        let radius = width;

        canvas.beginPath();
        canvas.arc( position.x, position.y, radius, 0, PI2, false );
        canvas.fill();
        canvas.closePath();

        canvas.beginPath();
        canvas.arc( parentPosition.x, parentPosition.y, radius, 0, PI2, false );
        canvas.fill();
        canvas.closePath();

        //--------------------------------
        // outline
        //--------------------------------
        canvas.lineWidth = 1.0;
        canvas.strokeStyle = OUTLINE_COLOR

        let radian = _phenotype.parts[p].currentAngle * PI_OVER_180;

        canvas.beginPath();
        canvas.arc( parentPosition.x, parentPosition.y, radius, Math.PI - radian, Math.PI - radian + Math.PI, false );
        canvas.stroke();
        canvas.closePath();

        canvas.beginPath();
        canvas.moveTo( x1, y1 );
        canvas.lineTo( x2, y2 );
        canvas.arc( position.x, position.y, radius, -radian, -radian + Math.PI, false );
        canvas.moveTo( x0, y0 );
        canvas.lineTo( x3, y3 );
        canvas.stroke();
        canvas.closePath();
    }






	//------------------------------------
	// render part splined
	//------------------------------------
	this.renderPartSplined = function(p)
	{
	    let parentIndex     = _phenotype.parts[p].parent;
        let position 		= _phenotype.parts[p].position;
        let parentPosition  = this.getPartParentPosition(p);
        let width           = _phenotype.parts[p].width;
        let parentWidth     = _phenotype.parts[ parentIndex ].width;

        //---------------------------
        // baby growing...
        //---------------------------
        if ( _growthScale < ONE )
        {
            width       = width         * _growthScale + EGG_SIZE * ( ONE - _growthScale );
            parentWidth = parentWidth   * _growthScale + EGG_SIZE * ( ONE - _growthScale );
        }

        let perpStartX  = _phenotype.parts[p].perpendicular.x;
        let perpStartY  = _phenotype.parts[p].perpendicular.y;
        let perpEndX    = _phenotype.parts[p].perpendicular.x;
        let perpEndY    = _phenotype.parts[p].perpendicular.y;

        let controlVectorLength = _phenotype.parts[p].length * _splineFactor;

        //-------------------------------------------------------------------------------
        // blend the two perpendiculars to represent the perpendicular of the joint
        //-------------------------------------------------------------------------------
        if (( p > 1 ) && ( ! _phenotype.parts[p].branch ))
        {
            perpStartX += _phenotype.parts[ parentIndex ].perpendicular.x;
            perpStartY += _phenotype.parts[ parentIndex ].perpendicular.y;

            let length = Math.sqrt( perpStartX * perpStartX + perpStartY * perpStartY );
            perpStartX /= length;
            perpStartY /= length;
        }


        if ( _phenotype.parts[p].child != NULL_INDEX )
        {
            perpEndX += _phenotype.parts[ _phenotype.parts[p].child ].perpendicular.x;
            perpEndY += _phenotype.parts[ _phenotype.parts[p].child ].perpendicular.y;

            let length = Math.sqrt( perpEndX * perpEndX + perpEndY * perpEndY );
            perpEndX /= length;
            perpEndY /= length;
        }

        //--------------------------------------
        // determine the two control vectors
        //--------------------------------------
        let control1DirectionX = -perpStartY;
        let control1DirectionY =  perpStartX;

        let control2DirectionX =  perpEndY;
        let control2DirectionY = -perpEndX;

        let control1VectorX = control1DirectionX * controlVectorLength;
        let control1VectorY = control1DirectionY * controlVectorLength;

        let control2VectorX = control2DirectionX * controlVectorLength;
        let control2VectorY = control2DirectionY * controlVectorLength;

        //--------------------------------------
        // scale the two perpendiculars
        //--------------------------------------
        perpEndX *= width;
        perpEndY *= width;

        if ( p === 1 )
        {
            perpStartX  *= width;
            perpStartY  *= width;
        }
        else
        {
            perpStartX  *= parentWidth;
            perpStartY  *= parentWidth;
        }

        //---------------------------------------------------------------------------------------
        // create the start and end points and the control points for the Bezier curve...
        //---------------------------------------------------------------------------------------
        let startLeftX      = parentPosition.x  - perpStartX;
        let startLeftY      = parentPosition.y  - perpStartY;
        let startRightX     = parentPosition.x  + perpStartX;
        let startRightY     = parentPosition.y  + perpStartY;
        let control1X       = parentPosition.x                  + control1VectorX;
        let control1Y       = parentPosition.y                  + control1VectorY;
        let control1LeftX   = parentPosition.x  - perpStartX    + control1VectorX;
        let control1LeftY   = parentPosition.y  - perpStartY    + control1VectorY;
        let control1RightX  = parentPosition.x  + perpStartX    + control1VectorX;
        let control1RightY  = parentPosition.y  + perpStartY    + control1VectorY;

        let endLeftX        = position.x        - perpEndX;
        let endLeftY        = position.y        - perpEndY;
        let endRightX       = position.x        + perpEndX;
        let endRightY       = position.y        + perpEndY;
        let control2X       = position.x                        + control2VectorX;
        let control2Y       = position.y                        + control2VectorY;
        let control2LeftX   = position.x        - perpEndX      + control2VectorX;
        let control2LeftY   = position.y        - perpEndY      + control2VectorY;
        let control2RightX  = position.x        + perpEndX      + control2VectorX;
        let control2RightY  = position.y        + perpEndY      + control2VectorY;


        //---------------------------------------
        // get color
        //---------------------------------------
        _colorUtility = this.calculatePartColor(p);
        let red   = Math.floor( _colorUtility.red   * 255 );
        let green = Math.floor( _colorUtility.green * 255 );
        let blue  = Math.floor( _colorUtility.blue  * 255 );

        canvas.fillStyle = "rgb( " + red + ", " + green + ", " + blue + " )";
        canvas.strokeStyle = OUTLINE_COLOR;


        //---------------------------------------
        // the beginning of a series of parts
        //---------------------------------------
        if ( p === 1 )
        {
            canvas.beginPath();
            canvas.arc( _phenotype.parts[ parentIndex ].position.x, _phenotype.parts[ parentIndex ].position.y, width, 0, PI2, false );
            canvas.fill();
            canvas.closePath();

            let radian = _phenotype.parts[ parentIndex ].currentAngle * PI_OVER_180;

            canvas.beginPath();
            canvas.arc
            (
                _phenotype.parts[ parentIndex ].position.x,
                _phenotype.parts[ parentIndex ].position.y,
                width,

                Math.PI - radian,
                Math.PI - radian + Math.PI,

                false
            );

            canvas.stroke();
            canvas.closePath();
        }

        //---------------------------------------
        // a terminating end part
        //---------------------------------------
                if ( _phenotype.parts[p].child === NULL_INDEX )
        {
            let s =  width * _phenotype.parts[p].endCapSpline;
            let f = -1.0;

            let axisNormalX = _phenotype.parts[p].axis.x / _phenotype.parts[p].length;
            let axisNormalY = _phenotype.parts[p].axis.y / _phenotype.parts[p].length;

            let startx  = endLeftX  + axisNormalX * f;
            let starty  = endLeftY  + axisNormalY * f;
            let endx    = endRightX + axisNormalX * f;
            let endy    = endRightY + axisNormalY * f;
            let c1x     = endLeftX  + axisNormalX * s;
            let c1y     = endLeftY  + axisNormalY * s;
            let c2x     = endRightX + axisNormalX * s;
            let c2y     = endRightY + axisNormalY * s;

            // Заливка закруглённого конца
            canvas.beginPath();
            canvas.moveTo( startx, starty );
            canvas.bezierCurveTo( c1x, c1y, c2x, c2y, endx, endy );
            canvas.lineTo( endRightX, endRightY );  // соединяем с правой стороной
            canvas.lineTo( endLeftX, endLeftY );    // и левой
            canvas.closePath();
            canvas.fill();

            // Outline (оставляем как было)
            canvas.beginPath();
            canvas.moveTo( startx, starty );
            canvas.bezierCurveTo( c1x, c1y, c2x, c2y, endx, endy );
            canvas.stroke();
        }

        //---------------------------------------
        // fill interior
        //---------------------------------------
        canvas.beginPath();
        canvas.moveTo( startLeftX, startLeftY );
        canvas.bezierCurveTo( control1LeftX, control1LeftY, control2LeftX, control2LeftY, endLeftX, endLeftY );
        canvas.lineTo( endRightX, endRightY );
        canvas.bezierCurveTo( control2RightX, control2RightY, control1RightX, control1RightY, startRightX, startRightY );
        canvas.lineTo( startLeftX, startLeftY );
        canvas.closePath();
        canvas.fill();

        canvas.beginPath();
        canvas.arc( parentPosition.x, parentPosition.y, parentWidth * 0.9, 0, PI2, false );
        canvas.fill();
        canvas.closePath();

        //---------------------------------------
        // draw outline
        //---------------------------------------
        canvas.lineWidth = 1.0;
        canvas.beginPath();
        canvas.moveTo( startLeftX, startLeftY );
        canvas.bezierCurveTo( control1LeftX, control1LeftY, control2LeftX, control2LeftY, endLeftX, endLeftY );
        canvas.moveTo( endRightX, endRightY );
        canvas.bezierCurveTo( control2RightX, control2RightY, control1RightX, control1RightY, startRightX, startRightY );
        canvas.stroke();
        canvas.closePath();
    }




	//------------------------------------------------------
	// calculate part color
	//------------------------------------------------------
	//------------------------------------------------------
	// set the state calculatePartColor needs, without drawing
	// (the graphics-card renderer asks for colors this way)
	//------------------------------------------------------
	this.prepareColors = function( phenotype, age, energy, growthScale, swimbot )
	{
    	_phenotype      = phenotype;
    	_age            = age;
    	_energy         = energy;
    	_growthScale    = growthScale;
    	_swimbot        = swimbot;
	}

	//-------------------------------------------------------------------
	// the same colours as calculatePartColor, for the whole body at once:
	// how much newborn white and how much dead grey is mixed in (for the
	// graphics card, where a call per part is too slow with thousands)
	//-------------------------------------------------------------------
	this.getColorMix = function( mix )
	{
	    mix.white = ZERO; mix.dead = ZERO;
	    if ( _swimbot.getEternal() ) { return; }
	    const oldAgeThreshold = _swimbot.getOldAgeThreshold();
	    if ( _age < oldAgeThreshold )
	    {
	        if      ( _age    < YOUNG_AGE_DURATION ) { mix.white = ONE - _growthScale; }
	        else if ( _energy < STARVING           ) { mix.dead  = ONE - Math.max( ZERO, _energy ) / STARVING; }
	    }
	    else { mix.dead = Math.max( ZERO, Math.min( ONE, ( _age - oldAgeThreshold ) / OLD_AGE_DURATION )); }
	}
	this.deadRed   = DEAD_COLOR_RED;
	this.deadGreen = DEAD_COLOR_GREEN;
	this.deadBlue  = DEAD_COLOR_BLUE;

	this.calculatePartColor = function(p)
	{
	    // Calculate the color if not cached
	    _colorUtility.red   = _phenotype.parts[p].red;
	    _colorUtility.green = _phenotype.parts[p].green;
	    _colorUtility.blue  = _phenotype.parts[p].blue;

	    if (!_swimbot.getEternal())
	    {
	        if ( _age < _swimbot.getOldAgeThreshold() )
	        {
	            if ( _age < YOUNG_AGE_DURATION )
	            {
	                //------------------------------
	                // newborns start white...
	                //------------------------------
	                _colorUtility.red   = ( ONE - _growthScale ) + ( _colorUtility.red   * _growthScale );
	                _colorUtility.green = ( ONE - _growthScale ) + ( _colorUtility.green * _growthScale );
	                _colorUtility.blue  = ( ONE - _growthScale ) + ( _colorUtility.blue  * _growthScale );
	            }
	            else
	            {
	                if ( _energy < STARVING )
	                {
	                    assert( _energy >= ZERO, "_energy >= ZERO" );

	                    let f = ONE - ( _energy / STARVING );

	                    _colorUtility.red   = DEAD_COLOR_RED    * f + _phenotype.parts[p].red   * ( ONE - f );
	                    _colorUtility.green = DEAD_COLOR_GREEN  * f + _phenotype.parts[p].green * ( ONE - f );
	                    _colorUtility.blue  = DEAD_COLOR_BLUE   * f + _phenotype.parts[p].blue  * ( ONE - f );
	                 }
	            }
	        }
	        else
	        {
	            let oldAgeThreshold = _swimbot.getOldAgeThreshold();

	            let f = ( _age - oldAgeThreshold ) / OLD_AGE_DURATION;

	            f = Math.max(0, Math.min(1, f)); // clamp to [0,1]
	            assert( f <= ONE,  "SwibotRenderer:renderPartSplined: f <= ONE"  );

	            // I had an assert before, but this is just graphics, and
	            // I assume if it is above 1, it's only by a tiny amount.
	            if ( f > ONE )
	            {
	                f = ONE;
	            }

	            _colorUtility.red   = DEAD_COLOR_RED    * f + _phenotype.parts[p].red   * ( ONE - f );
	            _colorUtility.green = DEAD_COLOR_GREEN  * f + _phenotype.parts[p].green * ( ONE - f );
	            _colorUtility.blue  = DEAD_COLOR_BLUE   * f + _phenotype.parts[p].blue  * ( ONE - f );
	        }
	    }

        assert( _colorUtility.red   >= ZERO, "_colorUtility.red   >= ZERO" );
        assert( _colorUtility.red   <= ONE,  "_colorUtility.red   <= ONE"  );

        assert( _colorUtility.green >= ZERO, "_colorUtility.green >= ZERO" );
        assert( _colorUtility.green <= ONE,  "_colorUtility.green <= ONE"  );

        assert( _colorUtility.blue  >= ZERO, "_colorUtility.blue  >= ZERO" );
        assert( _colorUtility.blue  <= ONE,  "_colorUtility.blue  <= ONE"  );

	    // sick (DISEASE_ENABLED): every other part pale - spots
	    if ( _swimbot.getIsSick && _swimbot.getIsSick() && ( p % 2 === 1 ))
	    {
	        _colorUtility.red   = 0.5 * _colorUtility.red   + 0.5 * 0.9;
	        _colorUtility.green = 0.5 * _colorUtility.green + 0.5 * 0.88;
	        _colorUtility.blue  = 0.5 * _colorUtility.blue  + 0.5 * 0.55;
	    }
	    return _colorUtility;
	}





	//--------------------------------
	// render genital
	//--------------------------------
	this.renderGenital = function()
	{
        let genitalLength = SWIMBOT_GENITAL_LENGTH * _growthScale;

        let x = _phenotype.parts[ GENITAL_INDEX ].position.x + _focusDirection.x * genitalLength;
        let y = _phenotype.parts[ GENITAL_INDEX ].position.y + _focusDirection.y * genitalLength;

		canvas.lineWidth = 1.0;
        canvas.strokeStyle = "rgba( 255, 255, 255, 0.7 )";
        canvas.beginPath();
        canvas.moveTo( _phenotype.parts[ GENITAL_INDEX ].position.x, _phenotype.parts[ GENITAL_INDEX ].position.y );
        canvas.lineTo( x, y );
        canvas.stroke();
        canvas.closePath();

        //--------------------------------------------------------
        // if pursuing a mate, show arrow head
        //--------------------------------------------------------
        if ( _brain.getState() === BRAIN_STATE_PURSUING_MATE )
        {
            let arrowLength = genitalLength * 0.4;
            let arrowWidth  = genitalLength * 0.25;
            let xLeft  = x - _focusDirection.y * arrowWidth - _focusDirection.x * arrowLength;
            let yLeft  = y + _focusDirection.x * arrowWidth - _focusDirection.y * arrowLength;

            let xRight = x + _focusDirection.y * arrowWidth - _focusDirection.x * arrowLength;
            let yRight = y - _focusDirection.x * arrowWidth - _focusDirection.y * arrowLength;

            canvas.beginPath();
            canvas.moveTo( xLeft, yLeft );
            canvas.lineTo( x, y );
            canvas.lineTo( xRight, yRight );
            canvas.stroke();
            canvas.closePath();
        }
	}





	//--------------------------------
	// render mouth
	//--------------------------------
	this.renderMouth = function()
	{
	    //------------------------------------------------------------------
	    // the beak's size follows the first body part (as in the original)
	    //------------------------------------------------------------------
	    let mouthLength = _phenotype.parts[1].width * 2.5;
	    if ( mouthLength < SWIMBOT_MIN_MOUTH_LENGTH ) { mouthLength = SWIMBOT_MIN_MOUTH_LENGTH; }

	    let mouthWidth = _phenotype.parts[1].width;
	    if ( mouthWidth < SWIMBOT_MIN_MOUTH_WIDTH ) { mouthWidth = SWIMBOT_MIN_MOUTH_WIDTH; }

	    mouthLength *= _growthScale;
	    mouthWidth  *= _growthScale;

	    let baseX = _phenotype.parts[ MOUTH_INDEX ].position.x;
	    let baseY = _phenotype.parts[ MOUTH_INDEX ].position.y;

        let mouthStartX = baseX + _focusDirection.x * mouthLength * 0.3;
        let mouthStartY = baseY + _focusDirection.y * mouthLength * 0.3;
        let mouthEndX   = baseX + _focusDirection.x * mouthLength;
        let mouthEndY   = baseY + _focusDirection.y * mouthLength;

        let basePerpX =  _focusDirection.y * _phenotype.parts[1].width * 0.5;
        let basePerpY = -_focusDirection.x * _phenotype.parts[1].width * 0.5;
        let endPerpX  =  _focusDirection.y * mouthWidth;
        let endPerpY  = -_focusDirection.x * mouthWidth;

        let leftJawX  = baseX - basePerpX;
        let leftJawY  = baseY - basePerpY;
        let rightJawX = baseX + basePerpX;
        let rightJawY = baseY + basePerpY;

        let leftEndX  = mouthEndX;
        let leftEndY  = mouthEndY;
        let rightEndX = mouthEndX;
        let rightEndY = mouthEndY;

        // (a herbivore going for a young one of its kind shows the predator's mouth)
        const isPredator = (( _phenotype.predatorLevel !== undefined ) && ( _phenotype.predatorLevel > PREDATOR_LEVEL_THRESHOLD ))
                        || (( _swimbot != null ) && _swimbot.getIsCannibalHunting && _swimbot.getIsCannibalHunting() );
        const state      = _brain.getState();

        //--------------------------------------------------------------
        // the beak opens while going for food (predators: prey or meat)
        //--------------------------------------------------------------
        const open = isPredator
            ? (( state === BRAIN_STATE_PURSUING_PREY ) || ( state === BRAIN_STATE_PURSUING_FOOD ))
            :  ( state === BRAIN_STATE_PURSUING_FOOD );

        if ( open )
        {
            leftEndX  -= endPerpX;
            leftEndY  -= endPerpY;
            rightEndX += endPerpX;
            rightEndY += endPerpY;
        }

		canvas.lineWidth = SWIMBOT_MOUTH_WIDTH;

        //--------------------------------------------------------------
        // color: herbivores like their first body part (as in the
        // original), predators red
        //--------------------------------------------------------------
        if ( isPredator )
        {
            canvas.fillStyle = PREDATOR_MOUTH_COLOR;
        }
        else
        {
            _colorUtility = this.calculatePartColor(1);
            let red   = Math.floor( _colorUtility.red   * 255 );
            let green = Math.floor( _colorUtility.green * 255 );
            let blue  = Math.floor( _colorUtility.blue  * 255 );
            canvas.fillStyle = "rgb( " + red + ", " + green + ", " + blue + " )";
        }

        canvas.beginPath();
        canvas.moveTo( mouthStartX, mouthStartY );
        canvas.lineTo( leftJawX,    leftJawY    );
        canvas.lineTo( leftEndX,    leftEndY    );
        canvas.lineTo( mouthStartX, mouthStartY );
        canvas.lineTo( rightEndX,   rightEndY   );
        canvas.lineTo( rightJawX,   rightJawY   );
        canvas.lineTo( leftJawX,    leftJawY    );
        canvas.fill();
        canvas.closePath();

        //--------------------------------------------------------------
        // predators: small teeth on the inside of the jaws
        //--------------------------------------------------------------
        if ( isPredator )
        {
            canvas.fillStyle = PREDATOR_TEETH_COLOR;

            if ( open )
            {
                // two teeth on each jaw, pointing towards the other jaw
                this.renderTeeth( mouthStartX, mouthStartY, leftEndX,  leftEndY,  endPerpX,  endPerpY );
                this.renderTeeth( mouthStartX, mouthStartY, rightEndX, rightEndY, -endPerpX, -endPerpY );
            }
            else
            {
                // closed: the teeth show as a fine zigzag along the seam
                let ax = mouthEndX - mouthStartX, ay = mouthEndY - mouthStartY;
                let px = endPerpX * 0.16, py = endPerpY * 0.16;
                canvas.beginPath();
                canvas.moveTo( mouthStartX, mouthStartY );
                for ( let k = 1; k <= 5; k++ )
                {
                    let t    = k / 6.0;
                    let side = ( k % 2 === 1 ) ? 1 : -1;
                    canvas.lineTo( mouthStartX + ax * t + px * side, mouthStartY + ay * t + py * side );
                }
                canvas.lineTo( mouthEndX, mouthEndY );
                canvas.lineWidth   = Math.max( 0.4, mouthWidth * 0.12 );
                canvas.strokeStyle = PREDATOR_TEETH_COLOR;
                canvas.stroke();
                canvas.closePath();
                canvas.lineWidth   = SWIMBOT_MOUTH_WIDTH;
            }
        }
        else
        {
            canvas.strokeStyle = "rgba( 255, 255, 255, 0.7 )";
            canvas.beginPath();
            canvas.moveTo( rightEndX,   rightEndY  );
            canvas.lineTo( mouthStartX, mouthStartY );
            canvas.lineTo( leftEndX,    leftEndY );
            canvas.stroke();
            canvas.closePath();
        }

        //--------------------------------------------------------------
        // outline of the outer jaw edges (as in the original)
        //--------------------------------------------------------------
        canvas.strokeStyle = OUTLINE_COLOR;
        canvas.beginPath();
        canvas.moveTo( leftJawX, leftJawY );
        canvas.lineTo( leftEndX, leftEndY );
        canvas.stroke();
        canvas.closePath();

        canvas.beginPath();
        canvas.moveTo( rightJawX, rightJawY );
        canvas.lineTo( rightEndX, rightEndY );
        canvas.stroke();
        canvas.closePath();
    }

	//------------------------------------------------------------------
	// two small triangular teeth along a jaw's inner edge (from the
	// mouth corner to the jaw tip), pointing in the (inwardX, inwardY)
	// direction
	//------------------------------------------------------------------
	this.renderTeeth = function( cornerX, cornerY, tipX, tipY, inwardX, inwardY )
	{
	    let ex = tipX - cornerX, ey = tipY - cornerY;
	    let inwardLength = Math.sqrt( inwardX * inwardX + inwardY * inwardY );
	    if ( inwardLength <= 0 ) return;

	    let toothHeight = Math.sqrt( ex * ex + ey * ey ) * 0.22;
	    let ix = inwardX / inwardLength * toothHeight;
	    let iy = inwardY / inwardLength * toothHeight;

	    canvas.beginPath();
	    for ( const t of [ 0.35, 0.7 ] )
	    {
	        let x0 = cornerX + ex * ( t - 0.12 ), y0 = cornerY + ey * ( t - 0.12 );
	        let x1 = cornerX + ex * ( t + 0.12 ), y1 = cornerY + ey * ( t + 0.12 );
	        let mx = cornerX + ex * t,            my = cornerY + ey * t;
	        canvas.moveTo( x0, y0 );
	        canvas.lineTo( mx + ix, my + iy );
	        canvas.lineTo( x1, y1 );
	        canvas.closePath();
	    }
	    canvas.fill();
	}

}//end of entire Swimbots function -------------------------
