//------------------------------------------------------------------------------
// CapsuleRenderer: draws thousands of "capsules" (a line segment with round
// ends - one body part) and dots (food bits) on the graphics card in a single
// draw call (WebGL2 instancing).
//
// Each frame:   begin()  ->  add(...) for every capsule  ->  draw(view...)
// A dot is a capsule whose two ends are the same point.
//------------------------------------------------------------------------------
// A body part is drawn tapered: thick at one end, thin at the other (as the
// detailed 2D drawing does with its parts).
const FLOATS_PER_CAPSULE = 10;  // ax ay bx by radiusA radiusB red green blue alpha

const VERTEX_SHADER = `#version 300 es
in vec2  corner;        // quad corner: (-1 | 1, -1 | 1)
in vec2  endA;          // per capsule
in vec2  endB;
in float radiusA;       // at endA
in float radiusB;       // at endB
in vec4  color;

uniform vec2  viewOrigin;   // pool coordinates of the top-left corner of the view
uniform vec2  viewSize;     // size of the view in pool units
uniform float pixelSize;    // pool units per screen pixel

out vec2  vLocal;           // position along / across the capsule
out float vLength;
out float vRadiusA;
out float vRadiusB;
out vec4  vColor;
out float vPixel;

void main()
{
    vec2  d   = endB - endA;
    float len = length( d );
    vec2  dir = ( len > 1e-6 ) ? d / len : vec2( 1.0, 0.0 );
    vec2  nrm = vec2( -dir.y, dir.x );

    float rA  = max( radiusA, pixelSize * 0.6 );   // never thinner than ~1 pixel
    float rB  = max( radiusB, pixelSize * 0.6 );
    float pad = max( rA, rB ) + pixelSize;          // room for a soft edge

    float lx = ( corner.x < 0.0 ) ? -pad : len + pad;
    float ly = corner.y * pad;
    vec2 world = endA + dir * lx + nrm * ly;

    vec2 clip = ( world - viewOrigin ) / viewSize * 2.0 - 1.0;
    gl_Position = vec4( clip.x, -clip.y, 0.0, 1.0 );

    vLocal  = vec2( lx, ly );
    vLength = len;
    vRadiusA = rA;
    vRadiusB = rB;
    vColor  = color;
    vPixel  = pixelSize;
}`;

const FRAGMENT_SHADER = `#version 300 es
precision highp float;

in vec2  vLocal;
in float vLength;
in float vRadiusA;
in float vRadiusB;
in vec4  vColor;
in float vPixel;

uniform float outline;      // 1 = up close: a dark rim, like the detailed 2D drawing

out vec4 outColor;

// signed distance to a capsule whose ends have different radii
// (along x from 0 to h; the "uneven capsule" of Inigo Quilez)
float unevenCapsule( vec2 p, float r1, float r2, float h )
{
    if ( h < abs( r1 - r2 ) + 1e-4 )                  // one end swallows the other: a disc
    {
        return ( r1 > r2 ) ? length( p ) - r1 : length( p - vec2( h, 0.0 )) - r2;
    }
    vec2  q = vec2( abs( p.y ), p.x );               // (across, along)
    float b = ( r1 - r2 ) / h;
    float a = sqrt( 1.0 - b * b );
    float k = dot( q, vec2( -b, a ));
    if ( k < 0.0 )   return length( q ) - r1;
    if ( k > a * h ) return length( q - vec2( 0.0, h )) - r2;
    return dot( q, vec2( a, b )) - r1;
}

void main()
{
    float d = unevenCapsule( vLocal, vRadiusA, vRadiusB, vLength );

    // soft one-pixel edge
    float coverage = clamp( 0.5 - d / vPixel, 0.0, 1.0 );
    if ( coverage <= 0.0 ) discard;

    vec3 rgb = vColor.rgb;
    if ( outline > 0.5 )
    {
        float rim = smoothstep( -2.2 * vPixel, -0.8 * vPixel, d );    // the last ~2 pixels inside the edge
        rgb *= mix( 1.0, 0.45, rim );
    }
    float a = vColor.a * coverage;
    outColor = vec4( rgb * a, a );   // premultiplied alpha
}`;

export class CapsuleRenderer
{
    private gl            : WebGL2RenderingContext;
    private program       : WebGLProgram;
    private vao           : WebGLVertexArrayObject;
    private instanceBuffer: WebGLBuffer;
    private data          = new Float32Array( 4096 * FLOATS_PER_CAPSULE );
    private count         = 0;
    private uniforms      : { viewOrigin: WebGLUniformLocation, viewSize: WebGLUniformLocation, pixelSize: WebGLUniformLocation, outline: WebGLUniformLocation };
    private hasContent    = false;

    //--------------------------------------------------------------------
    // returns null if the browser has no WebGL2
    //--------------------------------------------------------------------
    static create( canvas: HTMLCanvasElement ): CapsuleRenderer | null
    {
        const gl = canvas.getContext( "webgl2", { premultipliedAlpha: true, antialias: false, alpha: true } );
        if ( !gl ) return null;
        try
        {
            return new CapsuleRenderer( gl );
        }
        catch ( e )
        {
            console.warn( "WebGL renderer unavailable:", e );
            return null;
        }
    }

    private constructor( gl: WebGL2RenderingContext )
    {
        this.gl = gl;
        this.program = this.link( VERTEX_SHADER, FRAGMENT_SHADER );

        this.uniforms =
        {
            viewOrigin : gl.getUniformLocation( this.program, "viewOrigin" ),
            viewSize   : gl.getUniformLocation( this.program, "viewSize"   ),
            pixelSize  : gl.getUniformLocation( this.program, "pixelSize"  ),
            outline    : gl.getUniformLocation( this.program, "outline"    ),
        };

        this.vao = gl.createVertexArray();
        gl.bindVertexArray( this.vao );

        // the four corners of one quad, shared by all capsules
        const quad = gl.createBuffer();
        gl.bindBuffer( gl.ARRAY_BUFFER, quad );
        gl.bufferData( gl.ARRAY_BUFFER, new Float32Array( [ -1, -1,  1, -1,  -1, 1,  1, 1 ] ), gl.STATIC_DRAW );
        const corner = gl.getAttribLocation( this.program, "corner" );
        gl.enableVertexAttribArray( corner );
        gl.vertexAttribPointer( corner, 2, gl.FLOAT, false, 0, 0 );

        // one record per capsule
        this.instanceBuffer = gl.createBuffer();
        gl.bindBuffer( gl.ARRAY_BUFFER, this.instanceBuffer );
        const stride = FLOATS_PER_CAPSULE * 4;
        const attribute = ( name: string, size: number, offset: number ) =>
        {
            const location = gl.getAttribLocation( this.program, name );
            gl.enableVertexAttribArray( location );
            gl.vertexAttribPointer( location, size, gl.FLOAT, false, stride, offset * 4 );
            gl.vertexAttribDivisor( location, 1 );
        };
        attribute( "endA",   2, 0 );
        attribute( "endB",   2, 2 );
        attribute( "radiusA", 1, 4 );
        attribute( "radiusB", 1, 5 );
        attribute( "color",   4, 6 );

        gl.bindVertexArray( null );
    }

    private link( vertexSource: string, fragmentSource: string ): WebGLProgram
    {
        const gl = this.gl;
        const compile = ( type: number, source: string ) =>
        {
            const shader = gl.createShader( type );
            gl.shaderSource( shader, source );
            gl.compileShader( shader );
            if ( !gl.getShaderParameter( shader, gl.COMPILE_STATUS ) ) throw new Error( gl.getShaderInfoLog( shader ) );
            return shader;
        };
        const program = gl.createProgram();
        gl.attachShader( program, compile( gl.VERTEX_SHADER,   vertexSource   ) );
        gl.attachShader( program, compile( gl.FRAGMENT_SHADER, fragmentSource ) );
        gl.linkProgram( program );
        if ( !gl.getProgramParameter( program, gl.LINK_STATUS ) ) throw new Error( gl.getProgramInfoLog( program ) );
        return program;
    }

    //--------------------------------------------------------------------
    // collecting capsules
    //--------------------------------------------------------------------
    begin(): void
    {
        this.count = 0;
    }

    add( ax: number, ay: number, bx: number, by: number, radius: number,
         red: number, green: number, blue: number, alpha: number ): void
    {
        if ( ( this.count + 1 ) * FLOATS_PER_CAPSULE > this.data.length ) { this.grow( this.count + 1 ); }
        const d = this.data;
        let i = this.count * FLOATS_PER_CAPSULE;
        d[ i++ ] = ax;  d[ i++ ] = ay;
        d[ i++ ] = bx;  d[ i++ ] = by;
        d[ i++ ] = radius; d[ i++ ] = radius;
        d[ i++ ] = red; d[ i++ ] = green; d[ i++ ] = blue; d[ i++ ] = alpha;
        this.count ++;
    }

    //--------------------------------------------------------------------
    // room for n more capsules, to be written straight into reserved():
    // returns where in it the first of them starts (a whole body at once,
    // without a call per part)
    //--------------------------------------------------------------------
    reserve( n: number ): number
    {
        if ( ( this.count + n ) * FLOATS_PER_CAPSULE > this.data.length ) { this.grow( this.count + n ); }
        const start = this.count * FLOATS_PER_CAPSULE;
        this.count += n;
        return start;
    }
    reserved(): Float32Array { return this.data; }

    // give back reserved records that were not used
    release( n: number ): void { this.count = Math.max( 0, this.count - n ); }

    // a block of ready records (written by the physics threads, RenderData.ts)
    copyBlock( source: Float32Array, start: number, length: number ): void
    {
        if ( length <= 0 ) return;
        const at = this.reserve( length / FLOATS_PER_CAPSULE );
        this.data.set( source.subarray( start, start + length ), at );
    }
    readonly floatsPerCapsule = FLOATS_PER_CAPSULE;   // (ax ay bx by radiusA radiusB red green blue alpha)

    private grow( capsules: number ): void
    {
        let length = this.data.length;
        while ( capsules * FLOATS_PER_CAPSULE > length ) { length *= 2; }
        const bigger = new Float32Array( length );
        bigger.set( this.data );
        this.data = bigger;
    }

    //--------------------------------------------------------------------
    // draw everything collected since begin()
    //--------------------------------------------------------------------
    draw( viewLeft: number, viewTop: number, viewWidth: number, viewHeight: number ): void
    {
        const gl = this.gl;
        gl.viewport( 0, 0, gl.drawingBufferWidth, gl.drawingBufferHeight );
        gl.clearColor( 0, 0, 0, 0 );
        gl.clear( gl.COLOR_BUFFER_BIT );
        this.hasContent = this.count > 0;
        if ( this.count === 0 ) return;

        gl.useProgram( this.program );
        gl.uniform2f( this.uniforms.viewOrigin, viewLeft, viewTop );
        gl.uniform2f( this.uniforms.viewSize, viewWidth, viewHeight );
        const pixelSize = viewWidth / Math.max( 1, gl.drawingBufferWidth );
        gl.uniform1f( this.uniforms.pixelSize, pixelSize );
        gl.uniform1f( this.uniforms.outline, pixelSize < 0.9 ? 1 : 0 );   // (only up close, where the 2D drawing has rims)

        gl.enable( gl.BLEND );
        gl.blendFunc( gl.ONE, gl.ONE_MINUS_SRC_ALPHA );

        gl.bindBuffer( gl.ARRAY_BUFFER, this.instanceBuffer );
        gl.bufferData( gl.ARRAY_BUFFER, this.data.subarray( 0, this.count * FLOATS_PER_CAPSULE ), gl.DYNAMIC_DRAW );

        gl.bindVertexArray( this.vao );
        gl.drawArraysInstanced( gl.TRIANGLE_STRIP, 0, 4, this.count );
        gl.bindVertexArray( null );
    }

    //--------------------------------------------------------------------
    // wipe the layer (when the detailed 2D drawing takes over)
    //--------------------------------------------------------------------
    clear(): void
    {
        if ( !this.hasContent ) return;
        const gl = this.gl;
        gl.clearColor( 0, 0, 0, 0 );
        gl.clear( gl.COLOR_BUFFER_BIT );
        this.hasContent = false;
    }

    getCount(): number { return this.count; }

    // the canvas it draws into (GenePool copies its picture into the 2D canvas)
    getCanvas(): HTMLCanvasElement | OffscreenCanvas { return this.gl.canvas; }
}
